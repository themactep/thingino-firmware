# Self-healing watchdog — design spec (T41NQ thingino cameras)

Draft for review. No code yet — this is the plan so we build it once. All
scripts will ship in the overlay and be installed by runonce (one image, all
cameras).

## Goal

A camera that recovers itself from the failure modes we actually see, without a
human, and leaves a trail so we can tell *what* it healed from afterwards:

1. Network flaps — router rebooted, LAN briefly stuck. Wait it out, don't panic.
2. WiFi association lost — reconnect softly (no reboot).
3. WiFi stack wedged for a long time — reboot (last resort).
4. "Something just stopped working" (streaming daemon dead, no default route at
   all) — restart the daemon, or reboot if that's not enough.
5. Scheduled nightly reboot at 03:00 as cheap insurance against slow leaks.

Design principle: **escalate gently.** Cheapest fix first (reconnect), reboot
only when cheaper fixes have demonstrably failed for long enough that a router
reboot would already be over.

---

## Layers

### Layer 0 — hardware watchdog (already running, no work)

`watchdog -T 60 /dev/watchdog` is already up. If userspace hangs so hard it stops
petting `/dev/watchdog`, the SoC resets itself. This covers total lockups. We
build the network/daemon logic *on top* of this; it is the floor.

### Layer 1 — connectivity self-heal (the core)

Trigger: **cron, every 1 minute**, runs `selfheal.sh check`.
(Cron chosen over a daemon: each run is a fresh stateless process, so a bug in
the script can't wedge the watchdog itself; state lives in `/tmp`. Simpler and
more robust on embedded. Daemon considered and rejected for that reason.)

**Target = the default gateway, discovered dynamically (not a fixed IP):**
```sh
GW=$(ip route show default 2>/dev/null | awk '/default/{print $3; exit}')
```
- If `$GW` is **empty** → there is no default route at all (wlan0 and eth0 both
  dark / no DHCP). That *is* the "no network" signal — counts as a failure,
  heads toward reboot.
- If `$GW` is set → `ping -c1 -W3 "$GW"`. Reply = healthy.

**Single target, the gateway only — no secondary target.** Empirically, on this
network nothing is reachable without 10.0.0.1: with the router down you cannot
even ping another host in the same subnet (tested). The gateway is the single
L2/L3 hub here (the dumb switches / APs don't bridge without it), so a secondary
target like Frigate would go unreachable in lockstep with the gateway and buy
nothing. Gateway reachability *is* the network-up signal.

Failure counter in `/tmp/selfheal.netfail` (tmpfs → resets to 0 on every boot,
which is exactly what we want for reboot-loop safety).

**Escalation (defaults, all tunable at the top of the script):**

| consecutive fails | ~time | action |
|---|---|---|
| 0 (reply) | — | reset counter, exit (optionally heartbeat) |
| ≥ 3 | ~3 min | **soft recovery** (smart, see below), log the action |
| ≥ 10 | ~10 min | **reboot** — only if uptime > 180 s (anti reboot-loop); log reason to persistent log + `sync` first |

Rationale for 10 min: a router reboot is back in ~2–3 min, so ping succeeds again
and the counter resets long before we'd reboot. Only a genuinely stuck WiFi (or a
real long outage) ever reaches 10.

**Smart soft recovery** — don't blindly reboot WiFi; diagnose first:
```
state = wpa_cli -i wlan0 status  (or the interface's carrier/operstate)
  1. not associated (state != COMPLETED)      -> wpa_cli reconnect
  2. associated but wlan0 has no IPv4          -> renew DHCP (udhcpc / ifup)
  3. associated + IP but still no gateway ping -> upstream/network problem:
                                                   nothing local to fix, keep
                                                   counting toward reboot
```
This is the "jonkinlainen fiksu rutiini" — it distinguishes *my WiFi dropped*
(reconnect), *I lost my lease* (renew), and *the network beyond me is down*
(wait / eventually reboot).

Note: we deliberately do **not** rmmod/modprobe the RTL8733BU (USB module reload
can wedge the USB bus on this SoC). Reboot is the cleaner heavy hammer.

### Layer 2 — daemon / health self-heal

Same 1-minute run also checks the thing that actually matters — is the camera
*streaming*:
- `pidof <raptor process>` alive? (process name TBD on device — likely `rvd`.)
- Optional: RTSP port 554 listening (`netstat -ltn`).

If dead → `/etc/init.d/S31raptor restart`, log it. If it's still dead after a few
consecutive checks (≥ 3) → that's "simply not working" → reboot. This is the
"seuraa muitakin ongelmia, jos ei toimi: reboot" catch-all.

### Layer 3 — scheduled reboot (03:00, staggered, no RNG)

Cron: `0 3 * * * selfheal.sh reboot-scheduled`.

**Staggering without a random seed** (your catch — a seeded RNG can collide when
all cameras boot together after a power cut). Instead, a deterministic offset
from the **hostname** (stable; MAC is not — it changes on reflash):
```sh
offset=$(( 0x$(hostname | md5sum | cut -c1-4) % 900 ))   # 0–899 s window
sleep "$offset"; reboot
```
Same hostname → always the same offset; three different hostnames → three
different offsets, regardless of boot timing or entropy. With only three known
hostnames I'll verify the three offsets actually differ and hard-nudge if any
collide. Easily disabled (comment one cron line / a config flag).

### Layer 4 — logging subsystem

A single `log()` helper used by every layer. Purpose: a persistent, self-limiting
trail that **survives reboot** (so you can see *why* it rebooted), without wearing
the NOR flash or filling the overlay (directly relevant to finding #7 — constant
overlay writes are what hurt streaming).

**Target selection, per write:**
```
1. SD card  — if mounted (auto-detected from /proc/mounts, mmcblk0) AND it has
              free space (> SD_MIN, e.g. 5 MB)  -> primary log on SD
2. /root    — else if the overlay has > 200 KB free (df)  -> fallback log on flash
              (events only; no routine heartbeat — protect the flash)
3. syslog   — else nothing to disk; `logger` only (RAM, lost on reboot)
```
`logger` is called **always** (free, RAM) so `logread` shows live activity even
when nothing is written to disk.

**The 200 KB guard** is exactly your rule: writes to `/root` stop once the camera
has ≤ 200 KB free, so the self-heal log can never be the thing that fills the
overlay. Plenty of MB normally free; SD normally carries the log anyway (you
don't use the SD for anything else — recording lives in Frigate).

**Rotation & wear:**
- SD log: rotate at ~5 MB, keep 3. (Space is free; keep history.)
- /root log: rotate at ~64 KB, keep 1 (≤ ~128 KB total). Tiny by design.
- Reboot *reasons* are always written to the persistent log **and `sync`'d before
  the reboot call** — otherwise the reason dies with the RAM.

**Heartbeat:**
- Hourly line to SD: `alive, uptime=…, gw=…, rssi=…, idle=…`. Lets you confirm
  health and read recovery history at a glance.
- On the /root fallback, heartbeats are **suppressed** — only real events
  (recoveries, restarts, reboots) are written, to minimise flash wear.

---

### Layer 5 — flash / maintenance inhibit (anti-brick, critical)

A reboot in the middle of a firmware flash corrupts the NOR and bricks the camera.
This matters most for the remotely-sited units (reachable only by ladder + 12 V,
no practical U-Boot access) whose updates are done **over the network from running
Linux** - exactly the situation where the network-down (10 min) or scheduled 03:00
reboot could fire mid-write. So `inhibited()` gates every reboot and every action:

1. **Manual flag** — `selfheal.sh pause` (alias `stop`) creates `/tmp/selfheal.inhibit`;
   `resume` (alias `start`) removes it. `status` reports state. In tmpfs, so it
   auto-clears on reboot (can't get stuck on). Use for planned maintenance and for
   dev/debug fiddling with raptor (self-induced outages won't trigger a reboot).
2. **Known flash tools running** — pidof over `sysupgrade flashcp flash_erase mtd
   nandwrite ubiformat fw_setenv …`.
3. **Name-independent (the important one)** — any process holding an MTD device open
   (`/dev/mtdN` or `/dev/mtdblockN`) via a `/proc/*/fd` scan. Every flasher must open
   the device to write it; normal mounted filesystems are held by the kernel, not a
   process fd, so this never false-positives. Catches dd, web-UI CGIs, custom scripts
   - anything, regardless of name. This is what protects a firmware update a year from
   now when nobody remembers to pause. Verified: detects a device-holder, clears when
   it exits, full fd scan ~11 ms.

When inhibited the watchdog is fully passive and does **no disk I/O** (RAM-only
`logger`), since the flash is writing the very medium the log lives on. `do_reboot`
re-checks the inhibit even after the scheduled-reboot stagger sleep.

## Files (all in the overlay)

| file | role |
|---|---|
| `/usr/sbin/selfheal.sh` (source of truth in overlay) | main script: `check` / `reboot-scheduled`; contains the config block + `log()` |
| `/etc/init.d/S96selfheal` | at boot: install crontab entries, ensure `crond` is running; `start`/`stop` |
| crontab entries | `* * * * * /usr/sbin/selfheal.sh check` and `0 3 * * * /usr/sbin/selfheal.sh reboot-scheduled` |
| runonce hook | promote/install the script + crontab on first boot (same pattern as raptor.conf) |

Config block at the top of `selfheal.sh` (everything tunable in one place):
`SOFT_FAILS=3`, `HARD_FAILS=10`, `MIN_UPTIME=180`, `SD_MIN_KB=5000`,
`ROOT_MIN_KB=200`, `ROOT_LOG_MAX_KB=64`, `SD_LOG_MAX_KB=5000`,
`HEARTBEAT_MIN=60`, `REBOOT_HOUR=3`, `RAPTOR_INITD=S31raptor`, plus a master
`ENABLE_SCHEDULED_REBOOT=1`.

---

## Confirmed on-device facts (livingroom, verified)

- SD: `/dev/mmcblk0p1` mounted at **`/mnt/mmcblk0p1`** (vfat, rw) → primary log.
- Overlay (`/`, mtd4): 8 MB, **~7.6 MB free** → `df -k /root` gives the guard value.
- raptor core: **`pidof rvd`** works (PID 909); **RTSP :554 LISTEN** confirmed.
- crond: `-c /etc/cron/crontabs` → root tab **`/etc/cron/crontabs/root`**. thingino
  ships it with a commented `#0 3 * * * reboot -f` (their own 3:00 convention —
  validates ours). We append our block via S96selfheal and leave theirs alone.
- applets present: `ip`, `md5sum`, `wpa_cli`, `logger`, `hexdump`, `netstat`.
- **kernel.sysrq = 1** and `/proc/sysrq-trigger` present → the `echo b` force-reboot
  fallback is available. HW watchdog `-T 60` on `/dev/watchdog` stays as backstop.

## Status

**Implemented** — `overlay/root/usr/sbin/selfheal.sh` + `overlay/root/etc/init.d/S96selfheal`.
Passes `sh -n`; offset/gateway/df/rssi parsing verified against real device output
(three hostnames → distinct 03:00 offsets: entrance 14m44s, hallway 8m18s,
livingroom 10m25s). Pending your review, then overlay/runonce integration + build.

## Resolved decisions

- Target: gateway only (dynamic). Thresholds: **soft 3 min, reboot 10 min** (router
  outage ~35 s, AP reboot ~1-2 min → 10 min is safe). Reboot: `sync; reboot -f;`
  then sysrq; HW watchdog under it. Stagger: deterministic hostname md5 offset.
  Logging: SD-primary / `/root`-fallback (200 KB guard) / syslog always; heartbeat
  hourly to SD only. raptor liveness: `pidof rvd` + `:554`. Cron via
  `/etc/cron/crontabs/root`, appended idempotently every boot by S96selfheal.

## (historical) Open decisions

1. **Escalation thresholds** — soft at 3 min, reboot at 10 min. Good? What's the
   worst-case time your router is unreachable when you reboot *it* (so we set the
   reboot threshold safely above it)?
2. **Daemon liveness** — confirm the raptor process name to `pidof` (rvd?), and
   whether checking RTSP :554 is worth it.
3. **On-device facts I'll grab before coding:** SD mount path (`/proc/mounts`),
   overlay df path for the 200 KB guard, thingino's crontab location + how crond
   is launched, and that busybox has `ip` / `md5sum` / `wpa_cli`.

Once these are settled I'll write `selfheal.sh` + `S96selfheal` + the runonce
hook, wire them into the overlay and the deliverable, and we verify.
