# "Quality" variant — real speaker + analog mic (T41NQ DML16-Z533)

Some of these no-name T41NQ cameras ship as a slightly different variant: a real
external speaker (Class-D amplifier), an RS485/PTZ header (no motors fitted), and
in the unit seen here some thermal aging. The PCB is otherwise **identical** to the
plain twins — same T41NQ, GC5603, RTL8733BU, same SZ18201, same 16 MB flash, and a
**byte-identical U-Boot** (verified by sha256 of the boot partition 0x0–0x40000).
Only the vendor *application* firmware differs (a newer build with the speaker/PTZ
code). The thingino image and the whole bring-up are the same; only the two audio
details below and the mount orientation differ.

**The speaker connector + amp (GPIO 63) is on ALL of these boards**, not just the
"quality" unit — the plain twins have the same header, so you can add a speaker to
any of them by plugging a small speaker into that connector (no soldering needed).
Driving GPIO 63 high is therefore harmless on every unit: it just enables the amp,
which is silent anyway if no speaker is plugged in. So treat the amp-enable below as
a board-wide optional, not something unique to one camera.

## Audio wiring (from the vendor firmware)

Extracted from the vendor `audio.ko` `module_param` defaults (the vendor `load_drv`
`insmod`s it with no arguments, so these defaults are what the hardware uses):

| param | value | meaning |
|---|---|---|
| `internal_codec` | 1 | T41 internal audio codec |
| `dmic_enable` | 0 | **analog mic (amic)** — not a digital mic |
| `mic_mono_channel` | 1 | record left channel |
| `spk_gpio` | **63** | **speaker amplifier enable = GPIO 63 (PB31)** |
| `spk_level` | 1 | **active HIGH** (drive PB31 high to un-mute the amp) |

Consequences for thingino:

- **Microphone:** nothing to do. raptor's default `[audio] input = amic` matches the
  vendor. The mic works out of the box on this variant.
- **Speaker:** `[audio] ao_enabled = true` feeds the codec, but the external amp
  stays muted until **GPIO 63 (PB31) is driven high**. thingino has no built-in knob
  for a speaker-amp enable GPIO, so drive it with the init script here.

## Install

Copy the init script into this unit's overlay (per-unit, not the shared image):

```
install -m 0755 S12speaker-amp \
  user/<board>/overlay/root/etc/init.d/S12speaker-amp
```

Or drop it straight onto a running camera:

```
install -m 0755 S12speaker-amp /etc/init.d/S12speaker-amp
/etc/init.d/S12speaker-amp start
```

### Alternative: uenv gpio_default (may be overridden)

You can also try asserting the pin from U-Boot by adding `63O` to the board uenv
`gpio_default` (capital `O` = output HIGH, since the amp is active-high — same
convention as `61O` for wlan power and `81o`/`82o` for the LEDs = output low):

```
gpio_default=63O 81o 82o
```

Caveat: thingino regenerates `gpio_default` from thingino.json and drops pins it
doesn't know about (this is exactly what happens to `61O` for wlan — see
../../community/UPSTREAM-NOTES.md). So `63O` may not survive. After boot, verify:

```
fw_printenv gpio_default
cat /sys/class/gpio/gpio63/value    # 1 = amp enabled
```

If it was stripped, use the S12speaker-amp init instead — that always runs.

## Testing the speaker without ALSA / a working web UI

This variant's web UI is half-broken (prudynt remnants; the hold-to-speak button
does nothing). If `aplay`/`speaker-test` aren't in the image either, the neat trick
is the **thingino-button tap action**, which speaks the IP address through raptor's
ao path — with `gpio set 63` first, the announcement comes out the speaker and
confirms the whole codec → amp → speaker chain.

## Orientation

The sensor sits 180° rotated on the PCB, so the vendor firmware ran `flip=3` (from
its saved config, not the SDK init default which logs as 0). If you mount this unit
upside-down (so the sensor ends up physically upright) you need **no** flip — set
`shvflip=0` explicitly, because the thingino gc5603 driver defaults to `shvflip=1`
(mirror). Mounted the normal way up, use `shvflip=3` like the twins. Set by eye.
