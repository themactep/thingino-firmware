# T41NQ + GC5603 + RTL8733BU (USB WiFi) — complete thingino bring-up

No-name Hichip/Vanhua camera, board silk **DML16-Z533**. This documents every change
needed to get sensor, Ethernet, SD card and USB WiFi working under thingino, with the
register-level root causes. Written for the thingino community / upstreaming.

## Hardware

| Part | Detail |
|---|---|
| SoC | Ingenic **T41NQ** (XBurst2), 128 MB DDR |
| Sensor | GalaxyCore **GC5603**, MIPI 2-lane, i2c0 @ 0x31, native 2880×1620, MCLK 27 MHz PA15, reset PA18 |
| WiFi/BT | Realtek **RTL8733BU** — USB, combo WiFi+BT, VID 0BDA PID B733, power on **GPIO 61 (PB29)** |
| Ethernet | Motorcomm **SZ18201** PHY (RMII, 100M) |
| Flash | FM25Q128A 16 MB SPI-NOR |
| U-Boot | gtxaspec `u-boot` `ingenic-t-series` (2026.04), SPL+lzma |
| Kernel | 4.4.94 (thingino-linux) |

## Status

| Subsystem | State |
|---|---|
| GC5603 sensor, dual RTSP (2880×1620 + sub) | ✅ works |
| Ethernet | ✅ works |
| SD card (msc0, ADMA) | ✅ works |
| USB WiFi — enumerate, probe, fw dl, hal_init, **scan**, associate (STA), captive-portal AP, get IP, ping | ✅ works (scan confirmed — no RF/power margin left by the pad fix) |
| Audio — mic capture in RTSP stream | ✅ works (gain/volume tuned, see §7) |
| Day/night auto switch (IR-cut + colour/mono) | ✅ works via **gain trigger** (raptor RIC), thresholds tuned, see §7 |
| Day/night via physical light sensor (SADC AUX0 photoresistor) | ⚠️ tried but **unusable** for raptor RIC — SADC AUX0 reads inverted (0 = bright) and RIC has no invert; gain trigger used instead (§7) |
| IR illuminator LEDs (GPIO 81) / white LED (GPIO 82) | ⚠️ not wired in thingino (pin left in device-function mux + active-low; `light`/`gpio` don't drive them). Vendor toggles them at night via the ADC light sensor, but on this unit they are weak and behind daylight-passing plastic → negligible night-vision benefit. Documented, left as optional. |
| WiFi **and** Ethernet **simultaneously** | ❌ hardware limitation — one interface at a time (same on stock vendor firmware) |
| Cold reset when disturbing the Ethernet connector | ⚠️ **hardware, unit-specific — not firmware.** The RJ45 shares a cable harness with the power lead; tugging the connector momentarily disturbs power → cold reset (no log; boot shows `CPU0 RESET ERROR PC` = garbage = power reset, not a watchdog). A deployed, undisturbed camera is unaffected. |

## Root cause summary (why this board was hard)

Every CPM/GPIO/PHY/dwc2/DDR register read **identical** between stock and thingino U-Boot,
yet WiFi died ~4 s after `hal_init` and SD never finished ACMD41. Proven by booting the
**thingino kernel from the stock vendor U-Boot**: WiFi + SD both work → the difference is
entirely in what the **bootloader** leaves in a few pad-config registers before the kernel
runs. The decisive registers are an undocumented PB pad-config block at `0x10011000`:

- **`0x10011110`** must be `0x2F` — without it the RTL8733BU hard-detaches from USB ~2 s
  after enumeration. (Stock SPL writes it; thingino U-Boot proper re-clears an SPL write,
  so it must be re-applied in `board_late_init()`.)
- **`0x10011030`** — per-pin pad attribute. bit29 = PB29 (WiFi power), bit28 = PB28 (eth
  reset), bit30 = PB30. Stock clears bits 28/29/30; thingino leaves them set. With PB29's
  pad wrong the WiFi power pad is marginal → the chip **browns out ~4 s after RF starts**
  (all bulk-IN URBs complete `-71` at once, chip catatonic until a GPIO power-cycle).
  Clearing bits **29 and 30** (WiFi) also **fixes the SD card** (this register touches the
  MSC pins). **bit 28 is a genuine WiFi-vs-Ethernet conflict** on this register: clearing it
  helps WiFi but kills Ethernet, so we preserve it → Ethernet keeps working, and WiFi is
  fixed by the 29/30 change. (This matches stock: stock's full pad value breaks Ethernet,
  which is why the two interfaces are one-at-a-time on this board.)

Plus the standard USB-PHY register inheritance (USBPCR1/USBVBFIL/CDRs) that the A1-derived
`t41_usb_phy_init()` got wrong for T41, and the driver's probe-time MAC power-off that left
the chip's MCU catatonic.

## Changes — file by file

### 1. U-Boot patch — `package/all-patches/uboot/2026.04/9999-t41-dml16-vendor-pad-init.patch`

Adds `CONFIG_T41_VENDOR_PAD_INIT` (Kconfig) and, when enabled:
- **SPL** (`arch/mips/mach-xburst/t41/soc.c`, `board_init_f`): stock DML16-Z533 pad-function
  writes (PB6–19 funcsel, PB15, pad blocks `0x10011134/0x10011148/0x10012134/0x10012148`),
  PA20–22/29–31 → func1, USBVBFIL `0x00FF0080`, USBPCR1 `0x8A800090`.
- **board_late_init** (`board/ingenic/isvp-t41/isvp-t41.c`): re-applies the CPM USB-PHY
  register file (USBPCR `0x409919B8`, USBPCR1 `0xBAA00090`, USBVBFIL `0x00FF0080`, USBRDT,
  all CDRs incl. MSC0CDR), the pad reg **`0x10011110 = 0x2F`**, and the surgical WiFi pad
  fix **clear bits 29/30 of `0x10011030`** (preserving bit28 for Ethernet). Also disables the
  A1-derived `t41_usb_phy_init()` for this board.
- **DDR** (`arch/mips/dts/t41nq-isvp.dts`): drive strengths to stock values
  (CLK_RC 0x03→0x0F, DQX_RC 0x14→0x0F).

Enable with a U-Boot config fragment: `CONFIG_T41_VENDOR_PAD_INIT=y`
(e.g. `user/<board>/uboot-vendor-pad.config`, referenced from
`BR2_TARGET_UBOOT_CONFIG_FRAGMENT_FILES`).

### 2. RTL8733BU driver — CCV firmware flag

The chip is a C-cut (phydm `Cv=3` == halmac `CUTVersion==2`); the driver must be built with
`CONFIG_CCV_FW` or `hal_init` loads the wrong firmware array. In
`package/wifi-rtl8733bu/wifi-rtl8733bu.mk`, add to `WIFI_RTL8733BU_MODULE_MAKE_OPTS`:

```
USER_EXTRA_CFLAGS=-DCONFIG_CCV_FW
```

### 3. RTL8733BU driver — no MAC power-off after probe

`package/all-patches/wifi-rtl8733bu/0002-rtl8733bu-no-poweroff-after-probe.patch`:
in `hal/hal_com.c` `hal_read_mac_hidden_rpt()`, skip the USB-path `rtw_hal_power_off()` at
end of probe. On this board that power-off makes the chip's MCU catatonic (EP0 → EPROTO)
until a hard power cycle.

### 4. GC5603 sensor patch — `package/ingenic-sdk/0002-gc5603-t41-mclk-clkname.patch`

**This is the key freeze fix.** The gc5603 2880×1620@30fps mode is *designed* for a **27 MHz
MCLK** (driver register comment: "mclk 27Mhz / wpclk 252Mhz / vts 1750"). Running it at 24 MHz
makes the real frame rate ≠ the declared 30 fps, and the ISP AE code
(`tisp_ae_sensor_par_ctrls_update`, inside the tx-isp binary blob) then throws
"max fps error"/"min fps error", `isp_fw_process` stalls into D-state, and the **video freezes**
intermittently (irregular-looking, but caused by AE). This was the single biggest bug and was
misdiagnosed for a long time (CPU, day/night, flip patches — all ruled out by bisect).

The SoC clock tree (`/sys/kernel/debug/clk` after `mount -t debugfs none /sys/kernel/debug`):
`apll=1104`, `mpll=1400`, `vpll=1080` (otherwise unused), and there is **no epll**. `mux_cim`'s
parents are `{sclka, mpll, vpll}`. `div_cim` from apll gives `1104/46 = 24 MHz` (not 27);
`div_cim` from **vpll** gives `1080/40 = 27 MHz exactly`.

So the patch does two things:
- **clk names for this kernel:** `mux_cim0/1/2` → `mux_cim`, `div_cim0/1/2` → `div_cim`.
- **reparent to vpll:** `clk_get(NULL,"vpll")` (guarded with `IS_ERR_OR_NULL`), then
  `clk_set_parent(mux_cim, vpll)` and set rate `27000000`, so the sensor gets a **true 27 MHz**
  and really runs 30 fps. After the fix the ISP AE fps-error count is **0** and the freeze is gone.

(An earlier attempt ran the sensor at 24 MHz from apll; that mismatch is exactly what caused the
AE fps-error freeze.)

### 5. Camera profile — `configs/cameras/unknown_t41nq_gc5603_eth+rtl8733bu/`

`*_defconfig` (key lines):
```
BR2_ETHERNET=y
BR2_INGENIC_SOC_MODEL="t41nq"
BR2_SENSOR_1_NAME="gc5603"
BR2_PACKAGE_WIFI=y
BR2_PACKAGE_WIFI_RTL8733BU=y
BR2_AVPU_SCLKA=y
BR2_AVPU_CLK_550MHZ=y
BR2_PACKAGE_THINGINO_RAPTOR_CONF_SENSOR_RST_GPIO="18"   # the key sensor fix
BR2_PACKAGE_THINGINO_RAPTOR_CONF_SENSOR_MCLK="1"
BR2_PACKAGE_THINGINO_RAPTOR_CONF_SENSOR_FPS="30"
BR2_PACKAGE_THINGINO_RAPTOR_CONF_STREAM0_WIDTH="2880"
BR2_PACKAGE_THINGINO_RAPTOR_CONF_STREAM0_HEIGHT="1620"
BR2_PACKAGE_THINGINO_RAPTOR_CONF_STREAM0_FPS="30"
BR2_PACKAGE_THINGINO_RAPTOR_CONF_STREAM0_BITRATE="3000000"
BR2_PACKAGE_THINGINO_RAPTOR_CONF_STREAM1_WIDTH="1280"
BR2_PACKAGE_THINGINO_RAPTOR_CONF_STREAM1_HEIGHT="720"
BR2_PACKAGE_THINGINO_RAPTOR_CONF_STREAM1_FPS="30"
BR2_PACKAGE_THINGINO_RAPTOR_CONF_STREAM1_BITRATE="768000"
BR2_PACKAGE_THINGINO_BUTTON=y
BR2_PACKAGE_WIRELESS_TOOLS=y
BR2_PACKAGE_THINGINO_DEVSCRIPTS=y
BR2_PACKAGE_THINGINO_DIAG=y
BR2_PACKAGE_THINGINO_KOPT_DWC2=y
BR2_PACKAGE_THINGINO_KOPT_DWC2_OTG=y
```
(Do **not** add `BR2_INGENIC_SDK_GPIO_USERKEYS` — it is a no-op on 4.4.94; the button uses the
native gpio-keys path, see BUILD.md §9.)

`thingino.json`: `gpio.wlan = 61`, ircut "49 50", ir850 81, white 82.

The reset button also requires input support appended to
`board/ingenic/xburst2/kernel/4.4.94/t41.generic.config`
(`CONFIG_INPUT_EVDEV=y` / `CONFIG_INPUT_KEYBOARD=y` / `CONFIG_KEYBOARD_GPIO=y`) plus the
`gpio-keys` DTS node (see BUILD.md §9).

`*.uenv.txt`: `gpio_default=81o 82o`
(thingino auto-generates `gpio_default` from `thingino.json` without wlan, so the old `61O` was
redundant — U-Boot's vendor-pad-init asserts WiFi power on PB29/GPIO61 — and is dropped.)

### 7. Day/night + audio tuning (this board)

**Day/night — final solution uses the sensor GAIN trigger.** raptor's RIC owns the IR-cut
relay and switches on the sensor `total_gain`. The physical-light-sensor path (SADC) was a
**dead end** here: raptor's RIC expects the light reading where `0 = dark`, but this board's
SADC AUX0 reads `0 = bright` (**inverted**) and RIC has no invert option; the ISP-luma path
also reads ~0 here. So neither the ADC nor luma trigger works correctly — gain is used instead.

`/etc/raptor.conf`:

```
[ircut]
trigger = gain
mode = auto            # or `day` for a fixed-day install until thresholds are tuned
day_threshold  = 390000
night_threshold = 490000
```

`day_threshold`/`night_threshold` are per-unit values on the sensor `total_gain` (tune against
your unit's lit/dark gain), then `/etc/init.d/S31raptor restart`.

**thingino-daynightd must NOT run alongside raptor RIC.** Its init script `S97daynightd` starts
the daemon unconditionally (ignores `thingino.json daynight.enabled`), so both systems fight
over the IR-cut. The overlay ships `S99runonce`, which stops daynightd and removes its init
script (overlayfs whiteout) on first boot. See `custom/community/UPSTREAM-NOTES.md` finding #1.

Which hardware day/night toggles is controlled by `thingino.json` → `daynight.controls`
(color/ircut/ir850 = true, white = false).

(Note: the SoC SADC driver *can* be enabled — `CONFIG_MFD_INGENIC_SADC_V13=y` /
`CONFIG_MFD_INGENIC_SADC_AUX=y` — and the LDR read via `/dev/ingenic_adc_aux_0`, but it is
**NOT** usable for raptor day/night because of the inversion above. It is not the recommended
path; the gain trigger is used instead.)

**Audio** (raptor streamer, not prudynt — the web-UI audio page is prudynt-only and does
nothing here): mic capture works in the RTSP stream; the default gain was quiet. Tuned in
`[audio]` of `/etc/raptor.conf` and persisted via defconfig:

```
BR2_PACKAGE_THINGINO_RAPTOR_CONF_AUDIO_GAIN="31"     # vendor analog-gain value
BR2_PACKAGE_THINGINO_RAPTOR_CONF_AUDIO_VOLUME="92"
```

(Restart streamer with `/etc/init.d/S31raptor restart`; the image takes ~5 s to return.)

### 6. Kernel DTS — `board/ingenic/dts/unknown_t41nq_gc5603.dts`

Highlights: `&otg` + `&otg_phy` both `dr_mode = "host"`; `msc0` cd-gpio PB26 active-low +
`cd-inverted`, 25 MHz, msc0_pb; `mac0` RMII; sensor via raptor.conf.

## Register reference (kernel-runtime, working vs broken)

| addr | working (vendor uboot) | broken (thingino, pre-fix) | meaning |
|---|---|---|---|
| USBPCR   0x1000003c | 0x409919B8 | 0xC09919B8 | bit31 USB_MODE_ORG |
| USBVBFIL 0x10000044 | 0x00FF0080 | 0x00000000 | |
| USBPCR1  0x10000048 | 0xBAA00090 | 0xFAA00390 | ref-clk / word-if |
| pad 0x10011110 | 0x0000002F | 0x00000000 | USB stay-attached |
| pad 0x10011030 | 0x8E780000 | 0xFE780000 | bit28 PB28-eth / bit29 PB29-wifi / bit30 |
| pad 0x10011040 | 0x14000000 | 0x04000000 | bit28 PB28-eth (leave thingino's) |

Fix keeps `0x10011040` at thingino's value and only clears bits 29/30 of `0x10011030`
→ `0x9E780000` → WiFi + SD + Ethernet all work (one net iface at a time).

## Self-healing watchdog (`overlay/root/sbin/selfheal.sh` + `S96selfheal`)

An always-on camera should recover itself. `/sbin/selfheal.sh` runs every minute from cron
(installed idempotently by `S96selfheal`, which appends to `/etc/cron/crontabs/root`) and:

- **network** — pings the dynamically-discovered default gateway; escalates gently: a smart
  soft Wi-Fi reconnect after ~3 min, reboot only after ~10 min (a router reboot here is ~35 s,
  so it never trips on that; an AP reboot is covered too). Also re-asserts 802.11 power-save off.
- **streaming** — restarts raptor if `rvd` / RTSP `:554` is dead, with a start-up grace so a
  normal raptor restart's ~20–30 s RTSP gap is not counted as a fault.
- **scheduled** — staggered 03:00 reboot using a deterministic per-hostname offset (no RNG, so
  cameras that boot together after a power cut still reboot at different times).
- **anti-brick inhibit** — never reboots or acts during a firmware flash. `selfheal.sh pause`
  before maintenance/dev fiddling; and automatically if any flash tool is running or any process
  holds an MTD device open (a name-independent `/proc/*/fd` scan). This is what lets a *network*
  firmware update on a hard-to-reach unit not self-reboot mid-write and brick it. The reboot
  itself is made reliable: `sync; reboot -f;` then sysrq, with the hardware watchdog underneath.
- **logging** — SD-first (`/mnt/mmcblk0p1`), `/root` fallback that stops at 200 KB free, syslog
  always; hourly heartbeat. Steady state does zero NOR-flash writes.

Full design, measured facts and rationale: **`selfheal/SELFHEAL-DESIGN.md`**.

## Known issues / TODO

- **WiFi and Ethernet cannot run simultaneously** — hardware/pad conflict on `0x10011030`
  bit28; stock firmware has the same limitation. Acceptable: WiFi for deployment, Ethernet
  for servicing.
- **Cold reset when the Ethernet connector is disturbed** — the RJ45 is on a cable harness
  shared with the power lead; tugging it briefly interrupts power → cold reset. Hardware /
  unit-specific, not firmware. Irrelevant once the camera is installed and undisturbed.
  Practical usage: wired = keep the cable seated; wireless = leave it unplugged. Both work.
- The `-71` seen in an isolated idle/unassociated STA `insmod` test does not occur in normal
  operation. WiFi **scan**, associate, AP mode and traffic all work with the pad fix in place —
  the fix leaves no RF/power margin problem.
- Scanning from the web UI / captive portal may fail because the portal keeps wlan0 in AP mode
  (`ap_scan=2`); a plain STA scan (`wpa_supplicant -D nl80211 ... ap_scan=1` then
  `wpa_cli scan`/`scan_results`) works. This is a thingino portal-script mode-switch issue,
  not a hardware one.
- `gpio_default` env generator drops `61O` — that is fine: WiFi power (PB29/GPIO61) is asserted
  by the U-Boot vendor-pad-init patch, so the uenv needs only `81o 82o`. The overlay's
  `/etc/init.d/S95wifi-tune` sets the RTL8733BU knobs `en_fwps=0` / `dis_turboedca=1` once
  wlan0 is up (fewer stalls), **and disables 802.11 station power-save** (`iwconfig wlan0
  power off`). PS-on is the root cause of the cameras periodically dropping off the network:
  the mains-powered station dozes between beacons and the AP ages it out. `rtw_power_mgnt=0`
  is already the driver default yet PS is re-enabled at association, and `iw` is not installed,
  so the iwconfig WEXT toggle (re-asserted every minute by the self-heal watchdog) is the lever.
  See UPSTREAM-NOTES.md #10.
- **RTSP over WiFi (UDP)** shows a very regular ~58 s "drop" (session timeout from lost RTCP
  keepalive) and occasional grey/partial frames. Use **TCP RTSP transport on the client**
  (VLC `--rtsp-tcp`; go2rtc/Frigate `rtsp_transport: tcp`). Leave raptor `[rtsp]
  session_timeout` at its 60 s default (setting it to 0 backfires — rsd closes sessions at ~15 s).
- **Substream resolution must be divisible by 16** (H.264 macroblocks): `1280x720` works,
  `1440x810` / `960x540` / `1152x649` produce colored boxes / a broken substream.

## How the root cause was found (method, for the curious)

Booted thingino kernel from stock vendor U-Boot → WiFi+SD work → pinned the cause to U-Boot
register state. Dumped and diffed CPM + GPIO + pad blocks + DDR at both U-Boot prompts and at
kernel runtime; every delta was replicated one at a time. `0x10011110=0x2F` (chip stays on
bus) and `0x10011030` bits 28/29/30 (WiFi power pad marginal / SD MSC pads) were the two that
mattered; the Ethernet-vs-WiFi trade-off on bit28 was confirmed by the user's observation that
Ethernet fails under stock U-Boot (which clears bit28).
