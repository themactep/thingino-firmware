# Upstream notes — issues found bringing up T41NQ + GC5603 + RTL8733BU

These are findings that point at upstream (thingino) bugs/oversights rather
than being board-specific. They are worked around here (see overlay/ + runonce)
but should really be fixed upstream. Not clean patches — reports for maintainers.

## 1. daynightd starts even when raptor RIC handles day/night

`thingino-daynight` (merged daynightd/ircut/dusk2dawn) ships an init script
(S97daynightd) that starts `/usr/bin/daynightd` **unconditionally** — it does
not read `thingino.json` `daynight.enabled`. When raptor's RIC daemon is the
day/night handler (raptor.conf `[ircut] trigger=gain|adc|...`), both systems
drive the IR-cut and fight each other.

Workaround here: a run-once init (S99runonce) stops daynightd and rm's its
init script (overlayfs whiteout) on first boot.

Upstream fix: gate S97daynightd on `daynight.enabled` (or on "is raptor RIC
active"), so it doesn't auto-start when raptor owns day/night.

## 2. gpio.button_reset is read by ingenic-sdk but stripped by jct

`package/ingenic-sdk` install reads `jct get gpio.button_reset` to generate
`/etc/modules.d/gpio-userkeys`. But the jct schema does not include
`gpio.button_reset`, so the merge drops it from the final /etc/thingino.json,
and the generation never fires. Setting it in a camera profile has no effect.

Upstream fix: add `gpio.button_reset` (and `gpio.chime`) to the jct schema, or
have the SDK read the pre-merge value.

## 3. BR2_INGENIC_SDK_GPIO_USERKEYS is a no-op on the 4.4.94 tree

`CONFIG_INGENIC_GPIO_USERKEYS` only includes `<kver>/misc/gpio-userkeys/Kbuild`,
but that module source exists only under `3.10.14/misc/`, not `4.4.94/misc/`.
On a 4.4.94 build the flag silently builds nothing. The module also depends on
board-file symbols (`jz_button_device`, `board_buttons[]`) that don't exist on a
device-tree 4.4.94 kernel, so a straight port wouldn't link anyway.

Additionally the T41 4.4.94 kernel config has `# CONFIG_INPUT_EVDEV is not set`,
so even the standard gpio-keys path yields no /dev/input node out of the box.

Recommended path on 4.4.94 (used here): a DTS `gpio-keys` node + kernel
`CONFIG_INPUT_EVDEV=y` / `CONFIG_INPUT_KEYBOARD=y` / `CONFIG_KEYBOARD_GPIO=y`,
which the standard thingino-button daemon then reads. Mainline, no extra module.

Upstream fix: either add gpio-userkeys to the 4.4.94 tree, or (better) drop it in
favour of the DTS gpio-keys approach and enable EVDEV/KEYBOARD_GPIO in the T41
4.4.94 defconfig.

## 4. thingino-button DEVICE=auto does not find the gpio-keys device

With a working DTS gpio-keys node + EVDEV, the input node appears as
/dev/input/event0, but `thingino-button.conf` `DEVICE=auto` fails to open it
(daemon logs no keycodes). Setting `DEVICE=/dev/input/event0` explicitly makes
it work immediately (confirmed: keycode 28 / KEY_ENTER detected, TIMED actions
fire). Worked around in S99runonce (sed the conf + restart the daemon).

Upstream fix: make the auto-detect scan /dev/input/event* for a device that
advertises the configured keycodes.

## 5. No config knob for a speaker-amplifier enable GPIO

The "quality" variant of this board has a real external speaker behind a Class-D
amp whose ENABLE pin is a GPIO (here GPIO 63 / PB31, active-high; from the vendor
`audio.ko` params `spk_gpio=63 spk_level=1`). raptor's `[audio] ao_enabled=true`
drives the codec, but there is no thingino/raptor setting to assert an amp-enable
GPIO, so the speaker stays muted out of the box and needs a hand-rolled init that
does `gpio set 63` at boot (see variants/speaker-audio/).

thingino already reads `gpio.ir850`/`gpio.ircut`/`gpio.white`/`gpio.wlan` from
thingino.json. Upstream fix: add `gpio.speaker` (+ an active-level) to the schema and
have raptor (or an init) drive it high while ao is enabled. The vendor also exposes
`mic_mono_channel` and an internal-vs-external codec select as module params, worth
mirroring as raptor `[audio]` keys.

## 6. raptor RIC ADC day/night can't handle an inverted photoresistor

On this board the day/night LDR on SADC AUX0 is wired inverted: bright light reads
LOW (~0) and darkness reads HIGH (~14997 of a ~17995 full scale). raptor's RIC ADC
trigger assumes higher = brighter and has no invert option, so with this wiring it
never switches (and the ISP ae_luma path reads 0 here too, so trigger=luma is dead as
well - see below). We worked around it with trigger=gain, but the proper light-sensor
path needs the ADC polarity flipped.

Fix used (see patches/0005-ingenic-adc-aux-invert-module-param.patch): add an 'invert'
module param to drivers/mfd/ingenic_adc_aux.c. When non-zero the value returned to
userspace becomes (invert - reading), clamped at 0. Set ingenic_adc_aux.invert=20000
(kernel cmdline) or echo it at runtime; then RIC's adc trigger works with normal
adc_night/adc_day thresholds. General fix for any board with an inverted LDR.

Also observed: raptor RIC ae_luma reads 0 on gc5603/T41 regardless of exposure, so
trigger=luma never leaves "night". Worth an upstream look at the raptor<->tx-isp luma
stat readout; trigger=gain or the ADC-invert above are the workarounds.

Note on gain scale: the gc5603 total_gain values look "huge" (day/night thresholds in
the 390000-490000 range) but this is the sensor's native ISP gain unit - the vendor's
own calibrated gc5603 driver uses the same scale (again LUT max ~390000), so it is NOT
a miscalibration and needs no fix.

## 7. CONFIG_ERASE_SIZE_32K vs 64K jffs2 -> silent overlay corruption (THE big one)

The most important finding of the whole bring-up, and the hardest to diagnose because it
fails silently and masquerades as a dozen other problems.

Symptom: the writable overlay (the DATA jffs2 partition) does not work. Changes made at
runtime don't persist; a freshly-flashed overlay does not take effect; OLD /root files
and /etc config "resurrect" after every reflash even though the flashed image provably
contains the new content. It looks like a build bug, a flash bug, an SD-card bug, or a
thingino sysupgrade/config-preservation bug - it is none of those.

Root cause: an erase-block-size mismatch between the jffs2 image and the MTD driver.
- thingino builds the rootfs/DATA jffs2 with 64 KiB erase blocks (cleanmarkers every
  0x10000; standard for NOR).
- The Ingenic SFC v2 NOR driver (drivers/mtd/devices/ingenic_sfc_v2) sets the MTD
  erase size from a Kconfig choice: CONFIG_ERASE_SIZE_32K (default) vs
  CONFIG_ERASE_SIZE_64K. spinor_cmd.h: `#ifdef CONFIG_ERASE_SIZE_32K #define ERASE_SIZE
  32*1024 #else 64*1024`. Every chip-table entry uses `.erase_size = ERASE_SIZE`, and
  `flash->mtd.erasesize = ...->erase_size`.
- With the default CONFIG_ERASE_SIZE_32K=y, the MTD erases in 32 KiB blocks while the
  jffs2 was laid out for 64 KiB blocks. On mount the kernel logs:
    jffs2: Node at 0x.... with length 0x.... would run over the end of the erase block
    jffs2: Perhaps the file system was created with the wrong erase size?
  jffs2 then mis-manages the blocks: writes/erases don't land correctly, old nodes stay
  alive, new nodes don't stick. Over time this can also corrupt data / lose settings.

Confirmed on this board: FM25Q128A (id a14018), U-Boot "erase size 4 KiB", kernel SFC
"BE = 32K", jffs2 built at 64K.

Fix (kernel config, no source patch needed - the 64K erase command
NOR_ERASE_WRITE_ENABLE_64K is already fully implemented in the driver):

    # CONFIG_ERASE_SIZE_32K is not set
    CONFIG_ERASE_SIZE_64K=y

After this the MTD erase size is 64 KiB, matching the jffs2 and every partition (all are
64K-aligned: boot 320K, env 64K, kernel 2240K, rootfs 5568K, data 8192K). The jffs2
error disappears and the overlay finally works - flashes stick, /root updates, config
persists.

Upstream: for any board using ingenic_sfc_v2 whose rootfs/data jffs2 is 64K, the kernel
must default CONFIG_ERASE_SIZE_64K=y (or the jffs2 EBSIZE must be built to match the
configured MTD erase size). The current 32K default silently corrupts the overlay. This
affects far more than one camera - it touches every writable setting on the device.

How the fix is applied: it is a Kconfig *choice*, and thingino's t41.generic.config
already sets CONFIG_ERASE_SIZE_32K=y explicitly. CHANGE that line to
CONFIG_ERASE_SIZE_64K=y (do not append - a choice conflict reverts to 32K). The 64K
erase command NOR_ERASE_WRITE_ENABLE_64K is already implemented in the driver.

Observed impact beyond persistence: with the healthy 64K overlay, CPU idle rose and the
RTSP stream stopped dropping - the broken overlay had been generating constant blocking
flash I/O (failed writes, GC on mismanaged blocks) that stole CPU from the video pipeline
and disrupted streaming. One config line, three symptoms (no persistence, high CPU,
stream drops).

## 8. raptor: per-stream osd_enabled=false does not disable statically-defined OSD

Setting `[stream0] osd_enabled = false` (and stream1) does NOT remove the OSD if
`[osd.<name>]` elements are defined in raptor.conf - the statically-configured elements
render regardless. To disable OSD you must remove the `[osd.*]` element sections (or set
each element `visible = false`). osd_enabled appears to gate only runtime/raptorctl-added
OSD, not the static elements. Likely an unfinished area (raptor inherits a lot of
aspirational prudynt config that isn't fully wired yet).

## 9. raptor RIC/status should show the trigger's own input value

With trigger=adc the day/night light value shown by raptor/raptorctl is still the ISP
ae_luma, which reads 0 on gc5603/T41 (see #6). It would be far more useful to display the
ADC value (the signal the trigger actually uses). Related insight: this board carries a
physical photoresistor precisely because the ISP luma is unreliable here - the analog LDR
is the intended day/night source, not a vestige.

## Performance note: RTL8733BU Turbo-EDCA / fw power-save

The RTL8733BU driver's periodic firmware power-save and Turbo-EDCA re-tuning cost real
CPU and add latency on the shared USB/CPU path. Disabling both
(/proc/net/rtl8733bu/wlan0/en_fwps=0, dis_turboedca=1 once wlan0 is up - see
overlay/root/etc/init.d/S95wifi-tune) raised CPU idle from ~0% to ~30% under a two-stream
load on this T41, and stopped the every-2s "Turbo EDCA" churn in dmesg. Pair with raptor
[rvd] cpu_affinity=0 / [rsd] cpu_affinity=1 to spread video vs RTSP across the two cores.

## 10. RTL8733BU 802.11 power-save -> cameras drop off the network

Separately from the fw-ps/Turbo-EDCA above, 802.11 STATION power-save is the root cause of
these cameras periodically dropping off the network. Measured on this build:
- `iwconfig wlan0` reports `Power Management:on` even though the module param
  `rtw_power_mgnt` is already 0 (and rtw_ips_mode 0) - the driver turns PS back on at
  association regardless of the load-time param. S36wireless loads it with empty
  WLAN_MODULE_OPTS, so there is nothing to change there either.
- With PS on, a mains-powered always-streaming station dozes between beacons; that adds
  latency and, worse, lets the AP age the client out -> the drop.
- `iw` is NOT in the image (wireless-tools ships only iwconfig). iwconfig WEXT
  `iwconfig wlan0 power off` is confirmed to flip it to off and hold.

Fix used here: `iwconfig wlan0 power off` after wlan0 is up (S95wifi-tune), PLUS a
per-minute re-assert in the self-heal watchdog (ensure_ps_off), because a re-association
turns PS back on and a one-shot at boot would not survive that. The watchdog logs only
when it has to re-assert, so the log reveals how often the driver re-enables it.

Upstream: for an always-on camera the driver should default 802.11 PS off when
rtw_power_mgnt=0 (it currently doesn't), or thingino should assert `power off`
post-association in the wifi bring-up. Shipping `iw` (or an iwconfig-based hook) in the
wireless package would also help. This is arguably a more impactful fix than any tuning
above - it is the difference between a camera that stays on the network and one that
silently disappears.
