# Submitting the gc5603 shvflip fix to thingino

Target repo: https://github.com/thingino/ingenic-sdk
File: `4.4.94/sensor-src/t41/gc5603.c`

The fix is two local patches (`../patches/0003-*` and `../patches/0004-*`). For a
clean single-commit contribution, apply both to a checkout of the SDK, commit with
`COMMIT_MESSAGE.txt`, and open a PR.

## Generate a git-am-able patch from the build tree (no risk to your build)

The SDK source is a git checkout at `dl/ingenic-sdk/git`. Work on a throwaway
branch so your build tree stays pristine:

```
cd /workspace/dl/ingenic-sdk/git
git stash -u 2>/dev/null || true
git checkout -b shvflip-fix

patch -p1 < /workspace/package/ingenic-sdk/0003-gc5603-t41-shvflip-module-param.patch
patch -p1 < /workspace/package/ingenic-sdk/0004-gc5603-t41-apply-shvflip-at-streamon.patch

git add 4.4.94/sensor-src/t41/gc5603.c
git -c user.name='Oskari Rauta' -c user.email='oskari.rauta@gmail.com' \
    commit -F /workspace/user/.../custom/community/COMMIT_MESSAGE.txt
git format-patch -1 -o /tmp/                     # -> /tmp/0001-sensor-gc5603-t41-...patch

# restore pristine tree so buildroot keeps using the package/ patches:
git checkout - && git branch -D shvflip-fix
git stash pop 2>/dev/null || true
```

Then either:
- open a PR on a fork of thingino/ingenic-sdk with that commit, or
- attach `/tmp/0001-...patch` (it is `git am`-able) in an issue / to a maintainer.

## Sibling variants (optional, not tested here)

The same "param defined but never applied" pattern appears in the other gc5603
copies in the SDK. If maintainers want, the identical change can be applied to:

  - `4.4.94/sensor-src/t41/gc5603s0.c`, `gc5603s1.c`
  - `4.4.94/sensor-src/t40/gc5603.c`, `t31/gc5603.c`, `t41zrt/gc5603.c`
  - the matching files under `3.10.14/sensor-src/...`

Only the t41 4.4.94 variant was built and tested on real hardware; verify the
register offsets (0x022c / 0x0063) and the sensor_s_stream structure match before
claiming the others work.
