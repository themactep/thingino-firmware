# Kernel-runtime register diff: working (vendor U-Boot) vs broken (thingino U-Boot)

Both captured with thingino kernel+rootfs running. "Working" = booted from stock
vendor U-Boot (wifi confirmed: captive portal + phone HTTP session, `urb.status(-71)`
count = **0**). "Broken" = booted from an UNPATCHED thingino U-Boot (note: this was NOT
the v7 build — PB110=0 shows the vendor-pad patch wasn't present; user flashed an old
recovery image by mistake, but it still gives a clean vendor-vs-thingino delta).

## Deltas (only differing registers shown)

| Reg | addr | working (vendor uboot) | broken (thingino uboot) | note |
|---|---|---|---|---|
| CPCCR   | 0x10000000 | 0x9A**7**B5520 | 0x9A**0**B5520 | CE strobe bits, cosmetic |
| USBPCR  | 0x1000003c | 0x**4**09919B8 | 0x**C**09919B8 | bit31 USB_MODE_ORG (v7 sets 0x40..., matches working) |
| USBVBFIL| 0x10000044 | 0x00FF0080 | 0x00000000 | v7 fixes |
| USBPCR1 | 0x10000048 | 0xBAA00090 | 0xFAA00390 | v7 fixes |
| CDR 0x64| 0x10000064 | 0x800000FF | 0x00000000 | v7 fixes |
| MSC0CDR | 0x10000068 | 0x0030800B | 0x003080FF | dynamic (MMC drv) |
| CDR 0x6c| 0x1000006c | 0x40108000 | 0x00108000 | v7 fixes (bit30) |
| CDR 0x7c| 0x1000007c | 0x6000011B | 0x00000100 | v7 fixes |
| CDR 0xac| 0x100000ac | 0x40000002 | 0x00000001 | dynamic CDR |
| CDR 0xb0| 0x100000b0 | 0x00000001 | 0x00000001 | same |
| **PB +0x110** | 0x10011110 | **0x0000002F** | **0x00000000** | v7 fixes (the big USB-stay-attached fix) |
| **PB +0x030** | 0x10011030 | **0x8E780000** | **0xFE780000** | bits 28,29,30 — PB28 eth-rst / PB29 wifi-pwr / PB30. NOT in v7. |
| **PB +0x040** | 0x10011040 | **0x14000000** | **0x04000000** | bit28 — PB28 eth. eth-only. |

## Key interpretation (confirmed by user observation)

PB +0x030 / +0x040 are per-pin pad-attribute registers. bit28=PB28 (Ethernet reset),
bit29=PB29 (RTL8733BU power), bit30=PB30.

- Vendor U-Boot sets these for **wifi** → wifi works, but **Ethernet does NOT work under
  vendor U-Boot** (user observed eth0 no-link). The vendor pad state for PB28 breaks
  thingino's dwmac driver (which expects "no eth reset toggle needed").
- Thingino U-Boot sets them for **eth** → eth works, but PB29 (wifi power) pad is marginal
  → the RTL8733BU browns out ~4 s after RF starts (all bulk-IN URBs complete -71 at once,
  chip catatonic until GPIO power-cycle).

This is the last remaining root cause: **one shared pad register decides wifi-vs-eth.**

## Fix (v8, surgical)

In `board_late_init()`, clear only bits 29,30 of 0x10011030 (PB29 wifi + PB30),
**preserve bit 28 (PB28 eth)**, so both wifi and Ethernet work:

```c
u32 v = readl(0xb0011030);
v &= ~((1u<<29)|(1u<<30));   /* wifi pad -> vendor state, keep PB28 eth */
writel(v, 0xb0011030);
```

(Full-vendor 0x8e7e0000 would also clear bit28 and break Ethernet — hence surgical.)
Runtime devmem of this register did NOT help earlier because pad config must be set
before the kernel's USB/DDR init; board_late_init is pre-kernel, so it should.

## Full dumps

### working (vendor U-Boot), wifi OK, -71 count = 0
```
CPCCR=0x9A7B5520 USBPCR=0x409919B8 USBPCR1=0xBAA00090 USBVBFIL=0x00FF0080
OPCR=0x00001580  PB110=0x0000002F PB030=0x8E780000 PB040=0x14000000
CDR64=0x800000FF CDR6c=0x40108000 CDR7c=0x6000011B
```

### broken (unpatched thingino U-Boot), wifi dies ~4s
```
CPCCR=0x9A0B5520 USBPCR=0xC09919B8 USBPCR1=0xFAA00390 USBVBFIL=0x00000000
OPCR=0x00001580  PB110=0x00000000 PB030=0xFE780000 PB040=0x04000000
CDR64=0x00000000 CDR6c=0x00108000 CDR7c=0x00000100
```
